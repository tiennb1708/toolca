param (
    # --- String Parameters (Defaults for standalone testing) ---
    [string]$target_file_name = 'windows_hunt.zip',
    [string]$target_dir_name = 'windows_hunt',
    [string]$target_run_file = 'wqhunt.bat',
    [string]$target_key_name = 'vnptit_si',
    [string]$upload_path = '/vnptit_si',
    [string]$sftp_connection = 'vnptit_si@10.165.121.100',

    [int]$cpu_limit = 80,
    [int]$ram_limit = 80,
    [int]$disk_limitGB = 3,

    # --- Boolean Parameters (Switches) ---
    [switch]$no_run_tool,
    [switch]$no_upload_result,
    [switch]$no_cleanup
)
function Set-SSHPrivateKey {
    Param (
        [String[]]
        $KeyFilePath
    )
    takeown.exe /F "$KeyFilePath"

    $acl = Get-Acl "$KeyFilePath"
    $isProtected = $true
    $preserveInheritance = $false
    $acl.SetAccessRuleProtection($isProtected, $preserveInheritance)

    $identity = whoami
    $rights = 'FullControl'
    $type = 'Allow'
    $accessRule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $identity, $rights, $type
    $acl.SetAccessRule($accessRule)
    # Remove any remaining access rules
    $acl.Access |
    Where-Object { $_.IdentityReference -ne $identity } |
    ForEach-Object { $acl.RemoveAccessRule($_) }
    # Apply changes
    Set-Acl "$KeyFilePath" $acl
}

function Test-SystemReady {
    # CPU usage
    $cpu = (Get-CimInstance Win32_Processor |
        Measure-Object LoadPercentage -Average).Average

    # RAM usage
    $os = Get-CimInstance Win32_OperatingSystem
    $total = [float]$os.TotalVisibleMemorySize
    $free = [float]$os.FreePhysicalMemory
    $usedPercent = (($total - $free) / $total) * 100

    # Disk free space
    $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
    $freeGB = [math]::Round($disk.FreeSpace / 1GB, 2)

    Write-Output "CPU: $cpu % | RAM: $([math]::Round($usedPercent,2)) % | Disk Free: $freeGB GB"

    if ($cpu -lt $cpu_limit -and $usedPercent -lt $ram_limit -and $freeGB -gt $disk_limitGB) {
        return $true
    }

    return $false
}

$CurrentScriptPath = "$MyInvocation.MyCommand.Path"
try {
    if ($PSScriptRoot -eq $null) {
        $PSScriptRoot = Split-Path -Parent -Path "$CurrentScriptPath" 
    }
}
catch {
    Write-Output $_
}
$temp_path = "$PSScriptRoot"
Set-Location "$temp_path"

$zip = Join-Path "$temp_path" "$target_file_name"
$dest = Join-Path "$temp_path" "$target_dir_name"

$resControl = Test-SystemReady 

if ($resControl) {
    Write-Output "System ready... "

    Expand-Archive -LiteralPath "$zip" -DestinationPath "$temp_path" -Force -ErrorAction SilentlyContinue

    $TargetBatch = Join-Path "$dest" "$target_run_file"

    if ($no_run_tool -eq $false) {
        Write-Host "begin run..."
        $cmd = $env:ComSpec
        $arg = "/c `"$TargetBatch`""
        Start-Process -FilePath "$cmd" -ArgumentList "$arg" -Wait -NoNewWindow -PassThru -ErrorAction SilentlyContinue
        Write-Host "run end"
        $logFile = Get-ChildItem -Path "$dest" -Filter "auto*.zip" | Select-Object -First 1 | Select-Object FullName, Name
        if ($logFile) {
            $logDest = Join-Path "${temp_path}" $logFile.Name
            Move-Item $logFile.FullName "$logDest" -Force
        }
        else {
            Write-Host "Log file not found!!"
            exit 1
        }
    }

    if ($no_upload_result -eq $false) {
        Write-Host "begin upload..."
        $target_key_path = Join-Path "$dest" "$target_key_name"
        if (Get-Command "scp" -ErrorAction SilentlyContinue) {
            Set-SSHPrivateKey "$target_key_path"
            $cmd = 'scp'
            $arg = "-i `"$target_key_path`" -P 223 -o StrictHostKeyChecking=no `"$logDest`" ${sftp_connection}:`"$upload_path`""
            Start-Process -FilePath "$cmd" -ArgumentList "$arg" -Wait -NoNewWindow -PassThru -ErrorAction SilentlyContinue
            Write-Output "upload end"
        }
        else {
			$winscp = Join-Path $dest "WinSCP.exe"
			$ppk = "$target_key_path.ppk"
			$log = Join-Path $temp_path "WinSCP.log"
			$script = Join-Path $temp_path "upload.txt"
		
			if (!(Test-Path $winscp)) {
				Write-Error "WinSCP.exe not found: $winscp"
				return
			}
		
			if (!(Test-Path $ppk)) {
				$proc = Start-Process $winscp `
					-ArgumentList "/console /keygen `"$target_key_path`" /output=`"$ppk`"" `
					-Wait -PassThru -NoNewWindow
		
				if ($proc.ExitCode -ne 0 -or !(Test-Path $ppk)) {
					Write-Error "Failed to convert private key to PPK."
					return
				}
			}
		
			@(
				"option batch abort"
				"option confirm off"
				"open `"sftp://${sftp_connection}:223/`" -hostkey=* -privatekey=`"$ppk`""
				"put `"$logDest`" `"$($upload_path.TrimEnd('/'))/`""
				"exit"
			) | Set-Content -LiteralPath $script -Encoding ASCII
		
			$proc = Start-Process $winscp `
				-ArgumentList "/console /ini=nul /log=`"$log`" /script=`"$script`"" `
				-Wait -PassThru -NoNewWindow
		
			if ($proc.ExitCode -ne 0) {
				Write-Error "WinSCP upload failed (exit code $($proc.ExitCode)). Log: $log"
				return
			}
		}
    }
    if ($no_cleanup -eq $false) {
        Write-Output "cleanup... "
        Remove-Item -Path "$dest" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -Path "$zip" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -Path "${PSScriptRoot}\ca_windows.bat" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -Path $MyInvocation.MyCommand.Path -Recurse -Force -ErrorAction SilentlyContinue
    }
    Write-Output "finished... "
}
else {
    Write-Output "System busy... "
}