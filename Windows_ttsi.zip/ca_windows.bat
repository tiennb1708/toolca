@echo off

SET "current_path=%~dp0"
cd /d "%current_path%"

REM Set tool target file
set "target_file=%current_path%\ca_windows.ps1"

setlocal enabledelayedexpansion
setlocal enableextensions 

set "powershell_path=%SystemRoot%\sysnative\WindowsPowerShell\v1.0\powershell.exe"
If exist "%powershell_path%" (
    echo Runing from 32bit cmd...
) else (
    echo Runing native platform...
    set "powershell_path=%SystemRoot%\system32\WindowsPowerShell\v1.0\powershell.exe"
)

:run
echo Running task...

echo "%DATE% %TIME%: Start......"

start "" /b "%powershell_path%" -NoProfile -ExecutionPolicy Bypass -Command "& '%target_file%'" 

echo "Exit code: %ERRORLEVEL%"
	
:end    
echo "%DATE% %TIME%: End"
