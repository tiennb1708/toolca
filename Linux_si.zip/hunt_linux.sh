#!/bin/bash
SCRIPT_MANUAL=$(readlink -f "$0")
temp_path="$(dirname "$SCRIPT_MANUAL")"
target_file_name="linux_hunt.tar.gz"
target_dir_name="vci"
target_run_file="lqhunt.sh"
target_key_name="vnptit_si"
upload_path="/vnptit_si"
sftp_connection="vnptit_si@10.165.121.100"
only_scan="false"
cpu_limit=80
ram_limit=80
disk_limitGB=3

run_tool="true"
upload_result="true"
cleanup="true"

SYSTEM_READY_CHECK() {
    # CPU usage
    cpu_idle=$(top -bn1 | awk '/Cpu/ {print $8}')
    cpu=$(printf "%.0f" "$(echo "100 - $cpu_idle" | bc)")

    # RAM usage
    mem_total=$(free -m | awk '/Mem:/ {print $2}')
    mem_used=$(free -m | awk '/Mem:/ {print $3}')
    ram=$(awk "BEGIN {printf \"%.0f\", ($mem_used/$mem_total)*100}")

    # Disk free space
    disk_free=$(df -BG / | awk 'NR==2 {gsub("G","",$4); print $4}')

    echo "CPU: $cpu % | RAM: $ram % | Disk Free: $disk_free GB"

    if [ "$cpu" -lt "$cpu_limit" ] && [ "$ram" -lt "$ram_limit" ] && [ "$disk_free" -gt "$disk_limitGB" ]; then
        return 0
    else
        return 1
    fi
}

#> ARGUMENT FLAGS
while [ -n "$1" ]; do
    case $1 in
        -nr)
            run_tool=false
            shift ;;
        -nu)
            upload_result=false
            shift ;;
        -nc)
            cleanup=false
            shift ;;
    esac
done

cd "$temp_path"

tar_file="${temp_path}/${target_file_name}"
dest="${temp_path}/${target_dir_name}"

if SYSTEM_READY_CHECK; then
    echo "System ready"

    mkdir -p "$dest"
    tar -xzf "$tar_file" -C "$dest"

    # Add exclude
    #exception_config_file="$dest/directory-excludes.cfg"
    #echo -e "\n\/oradata\n\/dev\/oracleafd\n\/dev\/oracleasm\n\/backupset\n\/backup\n\/tidb\n\/u01\/app/19\n\/u01\/app/oracle\n\/u01\/app\n\/oggdata\n\/outputfile\n\/dev\/asm\n\/dev\/mapper/vgdata-lvdata" >> $exception_config_file

    if [ "$only_scan" == "true" ]; then
        sed -i 's/use_cllf\=true/use_cllf\=false/' "${dest}/lqhunt.config"
    fi

    if [ "$run_tool" == true ]; then
        target_file_path="${dest}/${target_run_file}"
        echo "run tool..."
		chmod +x "${target_file_path}"
        /bin/bash -c "\"${target_file_path}\""
        echo "run end"
        mv "$dest"/Logs_*.tar.gz "$temp_path"
    fi

    if [ "$upload_result" = true ]; then
		latest_log=$(find "$temp_path" -type f -name 'Logs_*' -exec ls -t {} + 2>/dev/null | head -1)
		if [ -n "$latest_log" ]; then
			key_path="$dest/$target_key_name"
			chmod 600 "$key_path"
			echo "put \"$latest_log\"" | sftp -i "$key_path" -P 223 -o StrictHostKeyChecking=no "$sftp_connection:$upload_path" > /tmp/sftp_log.txt 2>&1
			echo "Upload exit code: $?"
		else
			echo "No Logs_* file found"
		fi
	fi
    if [ "$cleanup" == true ];
    then
        echo "cleanup... "
        rm -rf "$dest"
        rm -rf "$tar_file"
        rm -rf "$SCRIPT"
        # remove file Logs sinh ra
        # rm -f "$dest"/Logs_*.tar.gz
    fi
    echo "finished"
    echo "finished"
else
    echo "System busy"
fi
